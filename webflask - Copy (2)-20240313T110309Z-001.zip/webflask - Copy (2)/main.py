from flask import Flask, render_template, request
import pandas as pd
from sklearn.tree import DecisionTreeRegressor

app = Flask(__name__)

# Load data from CSV file
def load_data():
    data = pd.read_csv("myfile.csv")
    return data

# Train the machine learning model
def train_model(data):
    # Drop rows with missing temperature values
    data = data.dropna(subset=["temp"])
    X = data.drop(columns=["temp"])
    y = data["temp"]
    model = DecisionTreeRegressor()
    model.fit(X, y)
    return model

# Predict temperature based on selected date
def predict_temperature(selected_date, model):
    # Extract day, month, and year from the selected date
    dd, mm, yyyy = map(int, selected_date.split('/'))
    # Create a DataFrame with the selected date
    query_data = pd.DataFrame([[dd, mm, yyyy]], columns=["day", "month", "year"])
    # Predict temperature using the trained model
    temperature = model.predict(query_data)
    return f"{temperature[0]:.2f}°C"

@app.route("/", methods=["POST", "GET"])
def predict():
    if request.method == 'POST':
        mm = request.form['mm']
        dd = request.form['dd']
        yyyy = request.form['yyyy']
        place = request.form.get('place')  # Get the optional country field
        selected_date = f"{dd}/{mm}/{yyyy}"

        # Load data from CSV file
        data = load_data()

        # Train the machine learning model
        try:
            model = train_model(data)
        except ValueError:
            return "Error: Input data contains NaN values."

        # Predict temperature based on selected date
        temperature = predict_temperature(selected_date, model)

        return render_template("temperature.html",place=place ,selected_date=selected_date, temperature=temperature)
    else:
        # If request method is GET, simply render the template
        return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
