from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Configure the MySQL database connection to your existing database
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/flask'
db = SQLAlchemy(app)

# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fn = db.Column(db.String(255), nullable=False)
    number = db.Column(db.String(255), nullable=False)
    course = db.Column(db.String(255), nullable=False)
    year = db.Column(db.String(255), nullable=False)
    sec = db.Column(db.String(255), nullable=False)
    major = db.Column(db.String(255), nullable=False)
    dep = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)



@app.route('/')
def home_page():
    return render_template('home.html', content="Testing")

@app.route('/records')
def records_page():
    users= User.query.all()
    return render_template('record.html', users
    =users)

@app.route('/add', methods=['GET', 'POST'])
def add_page():
    if request.method == 'POST':
        user_fn = request.form['user_fn']
        user_number = request.form['user_number']
        user_course = request.form['user_course']
        user_year = request.form['user_year']
        user_sec = request.form['user_sec']
        user_major = request.form['user_major']
        user_dep = request.form['user_dep']
        user_email = request.form['user_email']
        new_user = User(fn=user_fn, number=user_number, course=user_course, year=user_year, sec=user_sec, major=user_major, dep=user_dep, email=user_email)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('records_page'))
    return render_template('add.html')

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_page(id):
    user_to_update = User.query.get(id)
    if user_to_update is None:
        return redirect(url_for('records_page'))

    if request.method == 'POST':
        new_fn = request.form['user_fn']
        new_number = request.form['user_number']
        new_course = request.form['user_course']
        new_year = request.form['user_year']
        new_sec = request.form['user_sec']
        new_major = request.form['user_major']
        new_dep = request.form['user_dep']
        new_email = request.form['user_email']
        user_to_update.fn = new_fn
        user_to_update.number = new_number
        user_to_update.course = new_course
        user_to_update.year = new_year
        user_to_update.sec = new_sec
        user_to_update.major = new_major
        user_to_update.dep = new_dep
        user_to_update.email = new_email
        db.session.commit()
        return redirect(url_for('records_page'))

    return render_template('update.html', user=user_to_update)

@app.route('/delete/<int:id>')
def delete_page(id):
    user_to_delete = User.query.get(id)
    if user_to_delete is not None:
        db.session.delete(user_to_delete)
        db.session.commit()
    return redirect(url_for('records_page'))

if __name__ == '__main__':
    app.run(debug=True)
